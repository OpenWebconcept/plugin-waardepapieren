

    <input type="hidden" name="action" value="waardepapieren_form">
    <select id="bsn" name="bsn" required="">
        <option value="" style="color: lightgrey;">Kies een persoon</option>
        <option value="999999928">Miley  Sinclair</option>
        <option value="999999230">Ranata Van der Heijden</option>
        <option value="999997865">Clinton   Gavey</option>
        <option value="999999890">Rick  Wildenberg</option>
        <option value="999999887">Luuk  Noord</option>
        <option value="999999889">Michelle  Dautzenberg</option>
        <option value="999999886">Kevin   Ross</option>
        <option value="999999837">Martin  Timmers</option>
        <option value="999999888">Leyah  Hanzen</option>
        <option value="900003508">Anita Henrika de Kieft</option>
        <option value="900003509">John Willem de Kieft</option>
        <option value="900003510">Jan Henrik de Kieft</option>
        <option value="999999850">Annemarijn van Helvert</option>
    </select>
    <select id="type" name="type" required="">
        <option value="" style="color: lightgrey;">Kies een akte</option>
        <option value="akte_van_geboorte">Akte van geboorte</option>
        <option value="akte_van_huwelijk">Akte van huwelijk</option>
        <option value="akte_van_overlijden">Akte van overlijden</option>
        <option value="akte_van_registratie_van_een_parterschap">Akte van registratie van een partnerschap</option>
        <option value="akte_van_omzetting_van_een_huwelijk_in_een_registratie_van_een_partnerschap">Akte van omzetting van een huwelijk in een registratie van een partnerschap</option>
        <option value="akte_van_omzetting_van_een_registratie_van_een_partnerschap">Akte van omzetting van een registratie van een partnerschap</option>
        <option value="verklaring_van_huwelijksbevoegdheid">Verklaring van huwelijksbevoegdheid</option>
        <option value="verklaring_van_in_leven_zijn">Verklaring van in leven zijn</option>
        <option value="verklaring_van_nederlanderschap">Verklaring van Nederlanderschap</option>
        <option value="uittreksel_basis_registratie_personen">Uittreksel basis registratie personen</option>
        <option value="uittreksel_registratie_niet_ingezetenen">Uittreksel registratie niet ingezetenen</option>
        <option value="historisch_uittreksel_basis_registratie_personen">Historisch uittreksel basis registratie personen</option>
    </select>
    <select id="format" name="format" required="">
        <option value="" style="color: lightgrey;">Kies een format</option>
        <option value="pdf">pdf</option>
        <option value="png">png</option>
    </select>
    <input type="submit" value="Get my claim">
</form>